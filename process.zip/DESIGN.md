# High-Precision Industrial Intelligence: Design System Guidelines

## 1. Overview & Creative North Star: "The Synthetic Sentinel"
The Creative North Star for this design system is **"The Synthetic Sentinel."** In the context of industrial vision AI, the interface is not just a dashboard; it is a high-precision instrument. We move away from the "SaaS-standard" rounded corners and soft aesthetics toward a look that is architectural, authoritative, and technical.

The experience breaks the "template" look through **Rigid Geometry** (0px border radius) and **Intentional Asymmetry**. We prioritize data density and optical clarity. By utilizing a "Dark Mode Primary" approach, we reduce eye strain in factory environments while allowing the Mint Green accent to pop as a critical signal of "System Health" or "Object Detection."

---

## 2. Color Theory & Architectural Tones
The palette is rooted in the depth of `primary_container` (#152a3a) and the vibrance of `secondary` (#74d9b6).

*   **Primary (Midnight):** Used for structural authority and deep focus areas.
*   **Secondary (Mint):** Reserved for "Action," "Success," and "Vision Detection." It is our laser-focus color.
*   **The "No-Line" Rule:** Sectioning must **never** be defined by 1px solid borders. Boundaries are created through background shifts. For example, a `surface_container_high` module sits directly on a `surface` background. The eye perceives the edge through the shift in value, not a line.
*   **Surface Hierarchy & Nesting:** Use the tiers to create a "Tactical Stack." 
    *   **Base:** `surface` (#121414)
    *   **Workspaces:** `surface_container_low` (#1a1c1c)
    *   **Active Modules/Cards:** `surface_container_highest` (#333535)
*   **The "Glass & Gradient" Rule:** For floating HUD elements (like camera overlays), use `surface_container` with a 70% opacity and a `20px` backdrop-blur. To add "soul" to the technicality, apply a subtle linear gradient to main CTAs transitioning from `secondary` (#74d9b6) to `on_secondary_container` (#e2fff1) at a 135-degree angle.

---

## 3. Typography: The Technical Editorial
We utilize a dual-font strategy to balance industrial precision with modern readability.

*   **Display & Headlines (Space Grotesk):** This typeface provides the "HUD" feel. Its idiosyncratic letterforms (like the 'g' and 'y') feel engineered. Use `display-lg` (3.5rem) for hero metrics like "System Efficiency" and `headline-sm` (1.5rem) for module titles.
*   **Body & Labels (Inter):** For high-density data and UI controls, we use Inter. It is the workhorse of the system. 
    *   **Title-SM:** Used for interactive labels.
    *   **Label-SM:** Used for "Metadata" (e.g., timestamps, sensor IDs) in `on_surface_variant` (#c3c7cc).
*   **Hierarchy Note:** High-contrast typography scales are essential. A massive `display-md` metric should sit adjacent to a tiny, uppercase `label-sm` to create an "Editorial Intelligence" look.

---

## 4. Elevation & Depth: Tonal Layering
In this system, we do not use shadows to simulate height; we use light and opacity to simulate "State."

*   **The Layering Principle:** To lift an object, move it up the surface scale. A "Selected" industrial camera feed moves from `surface_container_low` to `surface_bright`.
*   **Ambient Shadows:** If a floating diagnostic panel is required, use a shadow with a 40px blur, 0px offset, and 6% opacity of `surface_tint`. It should feel like a soft glow from the screen, not a drop shadow from a physical light.
*   **The "Ghost Border" Fallback:** For accessibility in complex data tables, use a "Ghost Border": `outline_variant` (#43474c) at 15% opacity. It should be nearly invisible until the eye seeks it.
*   **Glassmorphism:** HUD overlays (Targeting Reticles, AI Bounding Boxes) should use semi-transparent `secondary` fills (10% opacity) with a 1px `secondary` Ghost Border to signify active AI processing.

---

## 5. Components: Engineered Primitives
All components follow the **0px Roundedness Scale** (Absolute Square).

*   **Buttons:**
    *   *Primary:* Solid `secondary` (#74d9b6) with `on_secondary` (#003829) text. High-contrast, maximum visibility.
    *   *Tertiary:* Transparent background with a `secondary` Ghost Border. Use for low-priority actions like "Export Log."
*   **Input Fields:** Use `surface_container_highest` as the fill. The bottom edge should have a 2px "Focus Bar" in `secondary` that appears only on interaction. Forbid full-box outlines.
*   **Cards & Lists:** **No Dividers.** Separate list items using the Spacing Scale (e.g., `spacing-2` / 0.4rem) and subtle alternating background tints between `surface_container_low` and `surface_container_lowest`.
*   **Industrial AI Special Components:**
    *   **The Reticle:** A 4-corner bracket system using `secondary` for object detection.
    *   **The Heatmap Overlay:** Use a gradient ramp from `primary` to `secondary` (Midnight to Mint) to show AI confidence scores.
    *   **Telemetry Chips:** Small, square-edged chips using `surface_variant` with `label-sm` text for real-time sensor data.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** embrace asymmetry. Place large metrics on the left and dense data logs on the right.
*   **Do** use the Spacing Scale strictly. Align elements to the `spacing-4` (0.9rem) or `spacing-8` (1.75rem) increments to maintain a "calibrated" feel.
*   **Do** use `secondary` sparingly. It is a "Signal" color. If everything is Mint Green, nothing is important.

### Don’t:
*   **Don’t** use rounded corners. Even a 2px radius breaks the industrial "Synthetic Sentinel" aesthetic.
*   **Don’t** use standard grey shadows. They muddy the Midnight Blue (`primary_container`) palette.
*   **Don’t** use dividers for lists. Use vertical whitespace (`spacing-3`) to create "clutter-free" data environments.
*   **Don’t** use "Alert Red" for everything. Use the `error` (#ffb4ab) token only for critical machine failure; use `tertiary` (#e6c09d) for "Warnings" to maintain the sophisticated color balance.